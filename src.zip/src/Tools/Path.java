package Tools;

public class Path {

    //Police d'écriture
    public static final String fontHeadCase = "../Asset/Fonts/Jurassic_Park.ttf";

    //image
    public static final String carte = "Asset/Images/Carte_plan.jpg";
    public static final String dino = "Asset/Images/dino.jpg";
    public static final String fond_bk = "Asset/Images/Black__1920x1080.png";
    public static final String logo = "Asset/Images/Javassic_Park_Logo2.png";
    public static final String cursor = "Asset/Images/Javassic_Park_Logo2.png";
    public static final String porte = "Asset/Images/teaserposter.jpg";



    //Musique
    public static final String MAIN_MENU_THEME = "src/Asset/Sons/javassic-park-theme-song.mp3";
    public static final String GAME_THEME = "src/Asset/Sons/nomdufichier.mp3";
}
