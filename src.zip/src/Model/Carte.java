package Model;

public class Carte {
}
