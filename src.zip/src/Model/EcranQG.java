package Model;

public class EcranQG {
}
