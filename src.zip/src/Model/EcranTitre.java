package Model;

public class EcranTitre {
}
