package Model;

public class GestionSoigneur {
}
