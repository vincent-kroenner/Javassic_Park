package Model;

public class EcranEnclos {
}
