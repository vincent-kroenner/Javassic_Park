package Main;

import javafx.application.Application;
import View.ViewHandler;

public class Main {
    public static void main(String[] args) {
        Application.launch(ViewHandler.class);
    }
}
